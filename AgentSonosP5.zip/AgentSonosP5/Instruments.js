//the functions of the instruments
function Instrument(x, y) {
  //instrument variables
  this.x = x;
  this.y = y;
  this.r = 25;
  this.col = color(0, 0, 0);
  this.active = false;

  this.show = function() {
    //draws the instruments
    strokeWeight(1);
    rectMode(CENTER);
    fill(this.col);
    rect(this.x, this.y, this.r, this.r);
    stroke(255);
  }

  this.intersects = function() {
    //pos is a vector variable that stores mouseX & Y coordinates to determine when
    //an instrument has been clicked on
    pos = createVector(mouseX, mouseY);
    // var d is the distance between instruments and the mouse cursor
    var d = dist(this.x, this.y, mouseX, mouseY);
    //if the distances is less than the radius of an instrument then it intersects
    if (d < this.r - (this.r / 2)) {
      return true;
    } else {
      return false;
    }
  }

  this.clicked = function() {
    //this function sets the colour of an instrument once it has been clicked on
    //var colours = [color(250, 104, 0), color(240, 163, 10), color(227, 200, 0), color(130, 90, 44), color(244, 114, 208), color(216, 0, 115), color(162, 0, 37), color(229, 20, 0), color(250, 104, 0), color(240, 163, 10), color(227, 200, 0), color(130, 90, 44), color(244, 114, 208), color(216, 0, 115), color(162, 0, 37), color(229, 20, 0), color(250, 104, 0), color(240, 163, 10), color(227, 200, 0), color(130, 90, 44), color(244, 114, 208), color(216, 0, 115), color(162, 0, 37), color(229, 20, 0)];
    //colours is an array that stores 8 predetermine colours to establish patterns
    var colours = [color(255, 0, 77), color(255, 163, 0), color(255, 236, 39), color(0, 228, 54), color(41, 173, 255), color(131, 118, 156), color(255, 119, 168), color(255, 204, 170), color(255, 0, 77), color(255, 163, 0), color(255, 236, 39), color(0, 228, 54), color(41, 173, 255), color(131, 118, 156), color(255, 119, 168), color(255, 204, 170), color(255, 0, 77), color(255, 163, 0), color(255, 236, 39), color(0, 228, 54), color(41, 173, 255), color(131, 118, 156), color(255, 119, 168), color(255, 204, 170)];
    // red, orange, yellow, green, blue, indigo, pink, peach
    //k stores the instruments Y coordinates, giving a different colour to each row
    this.col = colours[k];
    //if clicked the instrument becomes coloured and is considered active
    this.active = true;
  }

  this.reclicked = function() {
    //this function sets the colour of an instrument once it has been clicked off
    //below isthe colour black
    this.col = color(0, 0, 0);
    //if clicked the instrument turns black and is considered inactive
    this.active = false;
  }
  this.barcount = function() {
    //sets the colour of the instruments used strictly as labels
    this.col = color(101);
  }
}