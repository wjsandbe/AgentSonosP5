//the functions of the maestro
function Maestro(x, y) {
  //maestro variables
  this.x = x;
  this.y = y;
  this.play = false;

  this.move = function() {
    //if maestro is moving and the play/stop button is clicked then stop moving 
    //and move maestro back to the start
    if (this.play === false) {
      this.x = instruments[1].x - (instruments[0].r / 2);
    }
    //if maestro is not playing and the play/stop button is clicked then start moving
    else if (this.play === true) {
      this.x += 2;
    }
  }

  this.border = function() {
    //if the maestro goes offscreen then return to the start
    if (this.x > instruments[32].x + (instruments[0].r / 2)) {
      this.x = instruments[1].x - (instruments[0].r / 2);
    }
  }

  this.intersects = function() {
    //a loop to run through all the instruments
    for (var i = 0; i < instruments.length; i++) {
      //var d is the distance between instruments and the maestro
      var d = dist(this.x, this.y - height / 2, instruments[i].x, instruments[i].y);
      //if the distances is less than the diameter of an instrument then it intersects
      if (d < instruments[i].r) {
        return true;
      } else {
        return false;
      }
    }
  }

  this.display = function() {
    //draws the maestro
    strokeWeight(3);
    stroke(255);
    fill(255);
    line(this.x, this.y, this.x, this.y + (26 * 25));
  }
}