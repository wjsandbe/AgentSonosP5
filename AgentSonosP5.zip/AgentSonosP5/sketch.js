//instruments is an array that stores the actual rectangles that get drawn and clicked on 
var instruments = [];
//maestro is the horizontal scrolling bar that trigger the sounds
var maestro;
//pos is a vector variable that stores mouseX & Y coordinates to determine when
//an instrument has been clicked on
var pos;
//k stores a loop that correlates to the 24 instrument Y coordinates
var k;
//sounds is an array that stores the reference names of each sound file used
var sounds = ["C1", "D1", "E1", "F1", "G1", "A1", "B1", "CO1", "C2", "D2", "E2", "F2", "G2", "A2", "B2", "CO2", "DR1", "DR2", "DR3", "DR4", "DR5", "DR6", "DR7", "DR8"];
//files is an array that stores the actual file names of the sound files used
var files = ["files/PianoHiC.wav", "files/PianoHiB.wav", "files/PianoHiA.wav", "files/PianoHiG.wav", "files/PianoHiF.wav", "files/PianoHiE.wav", "files/PianoHiD.wav", "files/PianoHiOctaveC.wav", "files/PianoMiddleC.wav", "files/PianoMiddleB.wav", "files/PianoMiddleA.wav", "files/PianoMiddleG.wav", "files/PianoMiddleF.wav", "files/PianoMiddleE.wav", "files/PianoMiddleD.wav", "files/PianoMiddleOctaveC.wav", "files/Kick.wav", "files/ClosedHiHat.wav", "files/Snare.wav", "files/Crash.wav", "files/FloorTom.wav", "files/AltTom.wav", "files/HiTom.wav", "files/OpenHiHat.wav"];

function preload() {
  //this loop attaches a reference name to an actual file name for each sound file
  //for example: C1 = loadSound("files/PianoHiC.wav") and so forth for every sound file
  for (var s = 0; s < 24; s++) {
    sounds[s] = loadSound(files[s]);
  }
}

function setup() {
  //a good usuable size for a canvas, but could be altered
  createCanvas(950, 700);
  //resetSketch is a function that creates the basics of the sketch
  resetSketch();
  //creates a reset button, to reset the sketch
  var button = createButton("Reset");
  button.size(width / 11, width / 11);
  button.position(instruments[0].x - (instruments[0].r * 4), instruments[0].y - (instruments[0].r / 2));
  button.mousePressed(resetSketch);
  //creates a button that will start or stop the maestro and therefor start or stop 
  //playing the sound files
  var play = createButton("Play/Stop");
  play.size(width / 11, width / 11);
  play.position(instruments[0].x - (instruments[0].r * 4), instruments[131].y);
  play.mousePressed(Play);

}

function resetSketch() {
  //the function associated with the reset button
  //below are two loops; one that addresses horizontal arrays of instruments and
  //one that addresses verticles arrays of instruments
  //t stores the instrument index number
  var t = 0;
  for (var j = 0; j < 25; j++) {
    for (var i = 0; i < 33; i++) {
      instruments[t++] = new Instrument(i * 25 + 87.5, j * 25 + 37.5);
    }
  }
  //create the maestro upon setup
  maestro = new Maestro(instruments[1].x - (instruments[0].r / 2), 0);
}

function Play() {
  //the function associated with the play/stop button
  if (maestro.play === false) {
    maestro.play = true;
  } else if (maestro.play === true) {
    maestro.play = false;
  }
}

function draw() {
  background(51);
  //a loop to draw all the instruments as rectangles
  for (var i = 0; i < instruments.length; i++) {
    //show, draws the instruments
    instruments[i].show();
    if (i < 33 || i % 33 === 0) {
      //sets the colour of the top row and the left column of instruments
      instruments[i].barcount();
    }
  }
  //a maestro function that wraps the maestro around the sketch
  maestro.border();
  //a maestro function that moves the maestro
  maestro.move();
  //a function that plays soundfiles based on y coordinates & the instrument being active
  sound();
  //a function that create labels for the notes and the beat 
  labels();
  //a maestro funtion that draws the maestro
  maestro.display();
}

function sound() {
  //two loops that link a different sound file to each different group of y coordinates
  //soundsY is an array that stores the Y coordinate of each row of instruments
  var soundsY = [instruments[33].y, instruments[66].y, instruments[99].y, instruments[132].y, instruments[165].y, instruments[198].y, instruments[231].y, instruments[264].y, instruments[297].y, instruments[330].y, instruments[363].y, instruments[396].y, instruments[429].y, instruments[462].y, instruments[495].y, instruments[528].y, instruments[561].y, instruments[594].y, instruments[627].y, instruments[660].y, instruments[693].y, instruments[726].y, instruments[759].y, instruments[792].y];
  for (var i = 0; i < instruments.length; i++) {
    for (var t = 0; t < 24; t++) {
      //k stores a loop that correlates to the 24 instrument Y coordinates
      k = t;
      //if the instrument is active (has been clicked) play the cooresponding sound file
      if (maestro.x == instruments[i].x + 0.5 && instruments[i].y == soundsY[t] && instruments[i].active === true || maestro.x == instruments[i].x + 1.5 && instruments[i].y == soundsY[t] && instruments[i].active === true) {
        sounds[t].play();
      }
    }
  }
}

function labels() {
  //beats is an array that stores the beat labels
  var beats = ["0", "1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4"];
  //notes is an array that stores the note labels
  var notes = ["C", "D", "E", "F", "G", "A", "B", "C", "C", "D", "E", "F", "G", "A", "B", "C", "C", "D", "E", "F", "G", "A", "B", "C"];
  //notesY is an array that stores the Y coordinate of each row of instruments
  var notesY = [instruments[33].y, instruments[66].y, instruments[99].y, instruments[132].y, instruments[165].y, instruments[198].y, instruments[231].y, instruments[264].y, instruments[297].y, instruments[330].y, instruments[363].y, instruments[396].y, instruments[429].y, instruments[462].y, instruments[495].y, instruments[528].y, instruments[561].y, instruments[594].y, instruments[627].y, instruments[660].y, instruments[693].y, instruments[726].y, instruments[759].y, instruments[792].y];
  //a loop to draw the vertical note labels
  for (var n = 0; n < 24; n++) {
    stroke(0);
    fill(255);
    textAlign(CENTER);
    text(notes[n], instruments[0].x, notesY[n] + (instruments[0].r / 4));
  }
  //a loop to draw the horiztonal beat labels
  for (var b = 1; b < 33; b++) {
    stroke(0);
    fill(255);
    textAlign(CENTER);
    text(beats[b], instruments[b].x, instruments[0].y + (instruments[0].r / 4));
  }
}