function mouseClicked() {
  //a loop through every instrument to determine when the mouse intersects an instrument
  for (var i = 0; i < instruments.length; i++) {
    //if mouseX&Y intersects an instrument
    if (instruments[i].intersects(pos)) {
      //  console.log("x = " + instruments[i].x);
      //  console.log("y = " + instruments[i].y);
      //  console.log(i);
    }
    //soundsY is an array that stores the Y coordinate of each row of instruments
    var soundsY = [instruments[33].y, instruments[66].y, instruments[99].y, instruments[132].y, instruments[165].y, instruments[198].y, instruments[231].y, instruments[264].y, instruments[297].y, instruments[330].y, instruments[363].y, instruments[396].y, instruments[429].y, instruments[462].y, instruments[495].y, instruments[528].y, instruments[561].y, instruments[594].y, instruments[627].y, instruments[660].y, instruments[693].y, instruments[726].y, instruments[759].y, instruments[792].y];
    //a loop that associates with the instruments y coordinates via soundsY[]
    for (var t = 0; t < 24; t++) {
      //k stores a loop that correlates to the 24 instrument Y coordinates
      k = t;
      //if the instrument is black and is clicked then change colour
      if (instruments[i].intersects(pos) && instruments[i].active === false && instruments[i].y == soundsY[t]) {
        instruments[i].clicked();
        //if the instrument is coloured and is clicked then change to black
      } else if (instruments[i].intersects(pos) && instruments[i].active === true && instruments[i].y == soundsY[t]) {
        instruments[i].reclicked();
      }
    }
  }
}